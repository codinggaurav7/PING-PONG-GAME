# Ping_Pong
developed during web development training in coding ninjas 
may 2020 to oct 2020 (late submission 50% panelity)
